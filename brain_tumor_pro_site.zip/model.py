import os
from PIL import Image, ImageOps
import numpy as np

try:
    import torch
    import torchvision.transforms as transforms
    TORCH_AVAILABLE = True
except Exception:
    TORCH_AVAILABLE = False

MODEL_PATH = os.path.join('models', 'model.pth')

class Predictor:
    def __init__(self):
        self.model = None
        self.has_torch_model = False
        if TORCH_AVAILABLE and os.path.exists(MODEL_PATH):
            try:
                self.model = torch.load(MODEL_PATH, map_location=torch.device('cpu'))
                self.model.eval()
                self.has_torch_model = True
                print("Loaded PyTorch model from", MODEL_PATH)
            except Exception as e:
                print("Failed to load model weights:", e)
                self.has_torch_model = False
        else:
            if not TORCH_AVAILABLE:
                print("PyTorch not available — using mock predictor.")
            else:
                print("No model weights found at models/model.pth — using mock predictor.")

    def predict(self, image_path):
        if self.has_torch_model:
            return self._predict_with_torch(image_path)
        else:
            return self._mock_predict(image_path)

    def _preprocess_pil(self, img, size=(224,224)):
        img = ImageOps.grayscale(img)
        img = img.resize(size)
        arr = np.array(img).astype('float32') / 255.0
        arr = (arr - arr.mean()) / (arr.std() + 1e-8)
        if TORCH_AVAILABLE:
            import torch
            t = torch.from_numpy(arr).unsqueeze(0).unsqueeze(0)  # 1x1xHxW
            return t
        else:
            return arr

    def _predict_with_torch(self, image_path):
        img = Image.open(image_path)
        tensor = self._preprocess_pil(img)
        with torch.no_grad():
            out = self.model(tensor)
            if hasattr(out, 'sigmoid'):
                prob = float(out.sigmoid().item())
            else:
                try:
                    import torch.nn.functional as F
                    prob = float(F.softmax(out, dim=1)[0,1].item())
                except Exception:
                    prob = float(out.reshape(-1)[0].item())
        label = 'Tumor' if prob >= 0.5 else 'No Tumor'
        return {'tumor_probability': round(prob,4), 'label': label, 'explain': 'Model prediction (requires clinical validation).'}

    def _mock_predict(self, image_path):
        img = Image.open(image_path)
        img = ImageOps.grayscale(img)
        img = img.resize((224,224))
        arr = np.array(img).astype('float32') / 255.0
        brightness = arr.mean()
        prob = max(0.0, min(1.0, 1.0 - brightness))
        label = 'Tumor' if prob >= 0.5 else 'No Tumor'
        return {'tumor_probability': round(float(prob),4), 'label': label, 'explain': 'Mock prediction based on image brightness (for demo only).'}
