# Brain Tumor Detector — Professional Web App (Demo)

This is an improved, professional version of the Brain Tumor Detector demo web app.
It features a redesigned modern UI (glassmorphism + refined layout), better frontend structure,
deployment assets (Dockerfile and Procfile), and instructions to deploy on services like Render or Heroku.

**Important:** This demo uses a mock predictor if no model weights are provided. It is for educational/demo purposes only and not a medical device.

## What changed
- Premium, polished UI with responsive layout and animations
- Improved preview and results panel (includes history)
- Dockerfile and Procfile for easy deployment
- Clear instructions for running locally and deploying online

## Run locally
1. Create and activate a Python virtual environment.
2. Install dependencies: `pip install -r requirements.txt`
3. Run: `python app.py`
4. Open http://127.0.0.1:5000

## Deploy (example)
- **Render**: Connect a GitHub repo and set service to web, build command `pip install -r requirements.txt`, start command `gunicorn app:app`
- **Heroku**: `git push heroku main` (Procfile present)
- Or run the included Dockerfile.

## Notes about models
Place your PyTorch model at `models/model.pth`. The demo model wrapper expects a model that accepts a single grayscale tensor and returns a score for tumor probability.
