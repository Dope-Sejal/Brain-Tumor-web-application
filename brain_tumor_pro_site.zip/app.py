from flask import Flask, request, jsonify, send_from_directory, render_template, url_for
import os
from model import Predictor
from werkzeug.utils import secure_filename
from datetime import datetime
import json

UPLOAD_FOLDER = "uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

app = Flask(__name__, static_folder='static', template_folder='templates')
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

predictor = Predictor()

# Simple history stored in memory (demo). In production, use a DB.
history = []

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    if 'image' not in request.files:
        return jsonify({'success': False, 'error': 'no image uploaded'}), 400
    f = request.files['image']
    filename = secure_filename(f.filename)
    timestamp = datetime.utcnow().strftime('%Y%m%d%H%M%S%f')
    save_name = f"{timestamp}_{filename}"
    save_path = os.path.join(app.config['UPLOAD_FOLDER'], save_name)
    f.save(save_path)
    try:
        result = predictor.predict(save_path)
        entry = {
            'time': datetime.utcnow().isoformat(),
            'file': save_name,
            'result': result
        }
        history.insert(0, entry)
        # keep history to last 20
        if len(history) > 20:
            history.pop()
        return jsonify({'success': True, 'result': result, 'file': save_name})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/history', methods=['GET'])
def get_history():
    # return last N entries
    return jsonify({'history': history})

@app.route('/uploads/<path:filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

if __name__ == "__main__":
    print("Starting server at http://127.0.0.1:5000")
    app.run(debug=True, host='0.0.0.0')
