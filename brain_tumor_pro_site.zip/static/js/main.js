
const fileInput = document.getElementById('fileInput');
const dropzone = document.getElementById('dropzone');
const analyzeBtn = document.getElementById('analyzeBtn');
const clearBtn = document.getElementById('clearBtn');
const previewImg = document.getElementById('previewImg');
const labelText = document.getElementById('labelText');
const probText = document.getElementById('probText');
const explain = document.getElementById('explain');
const resultCard = document.getElementById('result');
const historyList = document.getElementById('historyList');
let selectedFile = null;

function setPreview(file){
  previewImg.src = URL.createObjectURL(file);
}

dropzone.addEventListener('click', ()=> fileInput.click());
fileInput.addEventListener('change', (e)=>{
  if(e.target.files.length){
    selectedFile = e.target.files[0];
    setPreview(selectedFile);
    resultCard.classList.add('hidden');
  }
});

dropzone.addEventListener('dragover', (e)=>{ e.preventDefault(); dropzone.classList.add('drag'); });
dropzone.addEventListener('dragleave', (e)=>{ dropzone.classList.remove('drag'); });
dropzone.addEventListener('drop', (e)=>{
  e.preventDefault();
  dropzone.classList.remove('drag');
  if(e.dataTransfer.files.length){
    selectedFile = e.dataTransfer.files[0];
    fileInput.files = e.dataTransfer.files;
    setPreview(selectedFile);
    resultCard.classList.add('hidden');
  }
});

analyzeBtn.addEventListener('click', async ()=>{
  if(!selectedFile){ alert('Please choose an image first.'); return; }
  analyzeBtn.disabled = true; analyzeBtn.textContent = 'Analyzing...';
  const fd = new FormData();
  fd.append('image', selectedFile);
  try{
    const res = await fetch('/predict', {method:'POST', body: fd});
    const data = await res.json();
    if(data.success){
      labelText.textContent = data.result.label;
      probText.textContent = (data.result.tumor_probability*100).toFixed(1) + '%';
      explain.textContent = data.result.explain;
      resultCard.classList.remove('hidden');
      // update history
      await fetchHistory();
    } else {
      alert('Error: ' + (data.error || 'unknown'));
    }
  } catch(err){
    alert('Request failed: ' + err.message);
  } finally {
    analyzeBtn.disabled = false; analyzeBtn.textContent = 'Analyze Image';
  }
});

clearBtn.addEventListener('click', ()=>{
  selectedFile = null;
  fileInput.value = null;
  previewImg.src = '/static/img/brain_placeholder.png';
  resultCard.classList.add('hidden');
});

async function fetchHistory(){
  try{
    const res = await fetch('/history');
    const data = await res.json();
    historyList.innerHTML = '';
    data.history.forEach(item => {
      const d = new Date(item.time);
      const el = document.createElement('div');
      el.className = 'history-item';
      el.innerHTML = `<div><strong>${item.result.label}</strong><div class="muted small">${d.toLocaleString()}</div></div><div class="prob">${(item.result.tumor_probability*100).toFixed(1)}%</div>`;
      historyList.appendChild(el);
    });
  }catch(e){ console.error(e); }
}

// initial load
fetchHistory();
